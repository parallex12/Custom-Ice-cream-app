import React, { useState } from 'react';
import { StyleSheet, Text, View, ActivityIndicator, TextInput, TouchableOpacity, ScrollView } from 'react-native';
import Header from "../components/Header";
export default function Signup({ navigation,route }) {
    const [name, setName] = useState(null);
    const [surname, setSurname] = useState(null);
    const [address, setAddress] = useState(null);
    const [houesno, setHouesno] = useState(null);
    const [intercom, setIntercom] = useState(null);
    const [email, setEmail] = useState(null);
    const [telephone, setTelephone] = useState(null);
    const [deliverytime, setDeliverytime] = useState(null);
    const [note, setNote] = useState(null);
    const [indicator,setIndicator]=useState("none");
    const [form,setForm]=useState("flex");
    const orderNow = () => {
        setForm("none");
        setIndicator("flex")
        fetch("https://www.adlerware.com/IcecreamMail.php", {
            method: 'post',
            headers: {
              'Accept': 'application/json, text/plain, */*', 
              'Content-Type': 'application/json'
            },
             body: JSON.stringify({pack:route.params.pack,name:name,surname:surname,address:address,houesno:houesno,intercom:intercom,email:email,telephone:telephone,deliverytime:deliverytime,note:note,order:route.params.order,price:route.params.price,gram:route.params.gram})         
        }).then((response)=>response.json()).then((response)=>{
            setForm("flex");
            setIndicator("none")
            alert(response)
            navigation.navigate('Packing')
        }).catch((error)=>{console.error(error)})
        
    }//order now ends here

    return (
        <View style={styles.container}>
            <Header title="Registration" />
            <ActivityIndicator animating={true} style={[styles.indicator,{display:indicator}]} size="large" />
            <ScrollView style={{ flex: 1, paddingHorizontal: 20, top: "5%",display:form }}>
                <Text style={{ fontSize: 20, fontWeight: "bold", textAlign: "center", marginBottom: "5%" }}>Inserisci i dati della spedizione</Text>
                <TextInput placeholder="Nome" style={styles.input} onChangeText={(val) => { setName(val) }} />
                <TextInput placeholder="Cognome" style={styles.input} onChangeText={(val) => { setSurname(val) }} />
                <TextInput placeholder="Indirizzo" style={styles.input} onChangeText={(val) => { setAddress(val) }} />
                <TextInput placeholder="Numero Civico" style={styles.input} onChangeText={(val) => { setHouesno(val) }} />
                <TextInput placeholder="Citifono" style={styles.input} onChangeText={(val) => { setIntercom(val) }} />
                <TextInput placeholder="Email" style={styles.input} onChangeText={(val) => { setEmail(val) }} />
                <TextInput placeholder="Numero di telefono" style={styles.input} onChangeText={(val) => { setTelephone(val) }} />
                <TextInput placeholder="Orario di consegna" style={styles.input} onChangeText={(val) => { setDeliverytime(val) }} />
                <TextInput placeholder="Note" style={styles.input} onChangeText={(val) => { setNote(val) }} />
                <Text style={{color:"black",fontSize:20}}>Prezzo totale :€{route.params.price}</Text>
                <TouchableOpacity   style={{backgroundColor:"#e49233d4",alignItems:"center",paddingVertical:10}} onPress={orderNow}>
                    <Text style={{color:"white"}}>Ordina ora</Text>
                </TouchableOpacity>
                
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: "column",
        backgroundColor: '#fff',
        justifyContent: "center",
    },indicator: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        height: 80,
        
      },
    input: {
        borderWidth: 1,
        paddingVertical: 10,
        paddingHorizontal: 10,
        borderColor: "grey",
        marginBottom: 5,
        backgroundColor: "#fff"
    },
});
