import React, { useState } from "react";
import { StyleSheet, Text, View, StatusBar, SafeAreaView, Image } from "react-native";
import Header from "../components/Header";
import Flavours from "../components/Flavours";
import Limit4 from "../components/Limit4";
import { TouchableOpacity } from "react-native-gesture-handler";


export default function Editor({ navigation, route }) {
    const [flav1, setFlav1] = useState("");
    const [flav2, setFlav2] = useState("");
    const [flav3, setFlav3] = useState("");
    const [flav4, setFlav4] = useState("");
    const [flav5, setFlav5] = useState("");
    const [flav6, setFlav6] = useState("");
    const [gramprice, setGramprice] = useState(null);
    const [items, setItems] = useState([{ packing: route.params.pack },{ Limit: route.params.limit },{Gram:route.params.gram}])
    const [count, setCount] = useState(1);
    const [flavoptions1, setFlavoptions1] = useState([{ left1: "19%", bRaduis1: 90, width1: "33%", rotate1: 12, btop1: "17%" }, { left2: "40%", bRaduis2: 0, width2: 80, rotate2: 190, btop2: "15%" }, { left3: "59%", bRaduis3: 90, width3: 75, rotate3: 192, btop3: "20.5%" }])
    const [flavoptions2, setFlavoptions2] = useState([{ left1: "19%", bRaduis1: 90, width1: "33%", rotate1: 12, btop1: "17%" }, { left2: "40%", bRaduis2: 0, width2: 80, rotate2: 190, btop2: "15%" }, { left3: "59%", bRaduis3: 90, width3: 75, rotate3: 192, btop3: "20.5%" }, { left3: "59%", bRaduis3: 90, width3: 75, rotate3: 192, btop3: "20.5%" }])
    const [flavoptions3, setFlavoptions3] = useState([{ left1: "19%", bRaduis1: 90, width1: "33%", rotate1: 12, btop1: "17%" }, { left2: "40%", bRaduis2: 0, width2: 80, rotate2: 190, btop2: "15%" }, { left3: "59%", bRaduis3: 90, width3: 75, rotate3: 192, btop3: "20.5%" }, { left3: "59%", bRaduis3: 90, width3: 75, rotate3: 192, btop3: "20.5%" }, { left3: "59%", bRaduis3: 90, width3: 75, rotate3: 192, btop3: "20.5%" }, { left3: "59%", bRaduis3: 90, width3: 75, rotate3: 192, btop3: "20.5%" }])
    console.disableYellowBox = true;
    //Setting if for gram box 500/750/1000
    const check = (val, name) => {
        if (route.params.gram == 500) {
            setGramprice(15)
            setFlavoptions1([{ left1: "16%", bRaduis1: 90, width1: "22%", rotate1: 12, btop1: "10.5%" }, { left2: "35%", bRaduis2: 0, width2: "21%", rotate2: 190, btop2: "15.7%" }, { left3: "55%", bRaduis3: 90, width3: "22.5%", rotate3: 192, btop3: "21.5%" }])
            if (count == 1) {
                setFlav1(val)
                setCount(count + 1)
                setItems([...items, { Flavour: name }])
            } else if (count == 2) {
                setFlav2(val)
                setCount(count + 1)
                setItems([...items, { Flavour: name }])
            } else if (count == 3) {
                setFlav3(val)
                setCount(count + 1)
                setItems([...items, { Flavour: name }])
            } else if (count > 3) {
                alert("Limite dei giusti raggiunto")
            }
        } else if (route.params.gram == 750) {

            if(route.params.pack=="Waffer"){
                setGramprice(21.50)
                setFlavoptions2([{ left1: "17%", bRaduis1: 90, width1: "17%", rotate1: 12, btop1: "8%" }, { left2: "32%", bRaduis2: 0, width2: "16%", rotate2: 190, btop2: "12%" }, { left3: "47%", bRaduis3: 0, width3: "18%", rotate3: 190, btop3: "16%" }, { left3: "64.6%", bRaduis3: 90, width3: 76, rotate3: 190, btop3: "20.2%" }])

            }else{
                setGramprice(17.50)
                setFlavoptions2([{ left1: "15%", bRaduis1: 90, width1: "17%", rotate1: 12, btop1: "10.5%" }, { left2: "30%", bRaduis2: 0, width2: "16%", rotate2: 190, btop2: "14.5%" }, { left3: "45%", bRaduis3: 0, width3: "17.5%", rotate3: 190, btop3: "18.2%" }, { left3: "61.6%", bRaduis3: 90, width3: 66, rotate3: 192, btop3: "22.5%" }])

            }// packing if ends here
            if (count == 1) {
                setFlav1(val)
                setCount(count + 1)
                setItems([...items, { Flavour: name }])
            } else if (count == 2) {
                setFlav2(val)
                setCount(count + 1)
                setItems([...items, { Flavour: name }])
            } else if (count == 3) {
                setFlav3(val)
                setCount(count + 1)
                setItems([...items, { Flavour: name }])
            } else if (count == 4) {
                setFlav4(val)
                setCount(count + 1)
                setItems([...items, { Flavour: name }])
            } else if (count > 3) {
                alert("Limite dei giusti raggiunto")
            }


        } else if (route.params.gram == 1000) {
            setGramprice(21.00)
            setFlavoptions3([{ left1: "15%", bRaduis1: 90, width1: "12%", rotate1: 12, btop1: "9%" }, { left2: "25%", bRaduis2: 0, width2: "11%", rotate2: 190, btop2: "11.7%" }, { left3: "35%", bRaduis3: 0, width3: "12.5%", rotate3: 190, btop3: "14.5%" }, { left3: "43.6%", bRaduis3: 0, width3: 55, rotate3: 190, btop3: "16.7%" }, { left3: "52.6%", bRaduis3: 0, width3: 55, rotate3: 190, btop3: "19%" }, { left3: "62.6%", bRaduis3: 100, width3: 60, rotate3: 192, btop3: "22%" }])
            if (count == 1) {
                setFlav1(val)
                setCount(count + 1)
                setItems([...items, { Flavour: name }])
            } else if (count == 2) {
                setFlav2(val)
                setCount(count + 1)
                setItems([...items, { Flavour: name }])
            } else if (count == 3) {
                setFlav3(val)
                setCount(count + 1)
                setItems([...items, { Flavour: name }])
            } else if (count == 4) {
                setFlav4(val)
                setCount(count + 1)
                setItems([...items, { Flavour: name }])
            } else if (count == 5) {
                setFlav5(val)
                setCount(count + 1)
                setItems([...items, { Flavour: name }])
            } else if (count == 6) {
                setFlav6(val)
                setCount(count + 1)
                setItems([...items, { Flavour: name }])
            } else if (count > 6) {
                alert("Limite dei giusti raggiunto")
            }

        }//gram if ends here
        
    }//check ends here


    //Next btn starts  here
    const next = () => {
        var c = "";
        for (var i = 3; i < items.length; i++) {
            c = c + items[i].Flavour + "<br>"
        }
       
        console.log(items)
        
        navigation.navigate('Checkout',{order:c,pack:items[0].packing,gram:items[2].Gram,price:gramprice})

    }
    //Next btn ends  here


//reset starts here
const reset = () => {

    setFlav1(null)
    setFlav2(null)
    setFlav3(null)
    setFlav4(null)
    setFlav5(null)
    setFlav6(null)
    setCount(1)
    setItems([{ packing: route.params.pack }, { Limit: route.params.limit }])
}

let path;
if (route.params.pack == "Waffer") {
    path = require('../assets/packing/Waffer.png');
} else {
    path = require('../assets/packing/Classica.png');
}
return (
    <SafeAreaView style={styles.container}>
        <Header />
        <View style={{ alignItems: "center", paddingTop: 50, paddingBottom: 30 }}>
            <Text style={{ fontSize: 20, fontWeight: "bold" }}> Personalizza la tua vaschetta gelato</Text>
            <Text style={{ fontSize: 13, textAlign: "center", paddingTop: 10 }}>{route.params.gram} gr (Selezione qualsiasi gusto limite 1-{route.params.limit})</Text>
        </View>
        {/* Limit3 starts here */}
        <View style={{ flex: 2, flexDirection: "column", alignItems: "center", justifyContent: 'center', position: "relative", display: route.params.gram == 500 ? "flex" : "none" }}>
            <Limit4 bg={flav1} left={flavoptions1[0].left1} bRadius={flavoptions1[0].bRaduis1} bWidth={flavoptions1[0].width1} bTop={flavoptions1[0].btop1} bRotate={flavoptions1[0].rotate1} />
            <Limit4 bg={flav2} left={flavoptions1[1].left2} bRadius={flavoptions1[1].bRaduis2} bWidth={flavoptions1[1].width2} bTop={flavoptions1[1].btop2} bRotate={flavoptions1[1].rotate2} />
            <Limit4 bg={flav3} left={flavoptions1[2].left3} bRadius={flavoptions1[2].bRaduis3} bWidth={flavoptions1[2].width3} bTop={flavoptions1[2].btop3} bRotate={flavoptions1[2].rotate3} />
            <Image source={path} style={{ width: "80%", height: '90%' }} />
        </View>
        {/* Limit3 ends here */}
        {/* Limit4 starts here */}
        <View style={{ flex: 2, flexDirection: "column", alignItems: "center", justifyContent: 'center', position: "relative", display: route.params.gram == 750 ? "flex" : "none" }}>
            <Limit4 bg={flav1} left={flavoptions2[0].left1} bRadius={flavoptions2[0].bRaduis1} bWidth={flavoptions2[0].width1} bTop={flavoptions2[0].btop1} bRotate={flavoptions2[0].rotate1} />
            <Limit4 bg={flav2} left={flavoptions2[1].left2} bRadius={flavoptions2[1].bRaduis2} bWidth={flavoptions2[1].width2} bTop={flavoptions2[1].btop2} bRotate={flavoptions2[1].rotate2} />
            <Limit4 bg={flav3} left={flavoptions2[2].left3} bRadius={flavoptions2[2].bRaduis3} bWidth={flavoptions2[2].width3} bTop={flavoptions2[2].btop3} bRotate={flavoptions2[2].rotate3} />
            <Limit4 bg={flav4} left={flavoptions2[3].left3} bRadius={flavoptions2[3].bRaduis3} bWidth={flavoptions2[3].width3} bTop={flavoptions2[3].btop3} bRotate={flavoptions2[3].rotate3} />
            <Image source={path} style={{ width: "80%", height: '90%' }} />
        </View>
        {/* Limit4 ends here */}

        {/* Limit6 starts here */}
        <View style={{ flex: 2, flexDirection: "column", alignItems: "center", justifyContent: 'center', position: "relative", display: route.params.gram == 1000 ? "flex" : "none" }}>
            <Limit4 bg={flav1} left={flavoptions3[0].left1} bRadius={flavoptions3[0].bRaduis1} bWidth={flavoptions3[0].width1} bTop={flavoptions3[0].btop1} bRotate={flavoptions3[0].rotate1} />
            <Limit4 bg={flav2} left={flavoptions3[1].left2} bRadius={flavoptions3[1].bRaduis2} bWidth={flavoptions3[1].width2} bTop={flavoptions3[1].btop2} bRotate={flavoptions3[1].rotate2} />
            <Limit4 bg={flav3} left={flavoptions3[2].left3} bRadius={flavoptions3[2].bRaduis3} bWidth={flavoptions3[2].width3} bTop={flavoptions3[2].btop3} bRotate={flavoptions3[2].rotate3} />
            <Limit4 bg={flav4} left={flavoptions3[3].left3} bRadius={flavoptions3[3].bRaduis3} bWidth={flavoptions3[3].width3} bTop={flavoptions3[3].btop3} bRotate={flavoptions3[3].rotate3} />
            <Limit4 bg={flav5} left={flavoptions3[4].left3} bRadius={flavoptions3[4].bRaduis3} bWidth={flavoptions3[4].width3} bTop={flavoptions3[4].btop3} bRotate={flavoptions3[4].rotate3} />
            <Limit4 bg={flav6} left={flavoptions3[5].left3} bRadius={flavoptions3[5].bRaduis3} bWidth={flavoptions3[5].width3} bTop={flavoptions3[5].btop3} bRotate={flavoptions3[5].rotate3} />

            <Image source={path} style={{ width: "80%", height: '90%' }} />
        </View>
        {/* Limit6 ends here */}
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-around" }}>
            <TouchableOpacity style={{ padding: 5, borderRadius: 5, backgroundColor: "#e49233d4" }} onPress={reset}>
                <Text style={{ fontSize: 15, color: "#fff" }}>Reset</Text>
            </TouchableOpacity>
            <Text style={{ fontSize: 15, fontWeight: "bold" }}>Scegli I gusti</Text>
            <TouchableOpacity style={{ padding: 5, borderRadius: 5, backgroundColor: "#e49233d4" }} onPress={next}>
                <Text style={{ fontSize: 15, color: "#fff" }}>Avati</Text>
            </TouchableOpacity>
        </View>

        <View style={{ flex: 1, flexDirection: "row", top: "15%" }}>
            <Flavours src={require("../assets/classic/chocolate.png")} name="Cioccolato" LimitHandler={check} color="#805a46" />
            <Flavours src={require("../assets/classic/milk.png")} name="Fiordilatte" LimitHandler={check} color="#fdfff5" />
            <Flavours src={require("../assets/classic/pistachio.png")} name="Pistacchio" LimitHandler={check} color="#efdfc4" />
            <Flavours src={require("../assets/classic/hazelnut.png")} name="Nocciola" LimitHandler={check} color="#a38276" />
            <Flavours src={require("../assets/classic/whipped-cream.png")} name="Crema" LimitHandler={check} color="#fffdd0" />
        </View>
        <View style={{ flex: 1, flexDirection: "row", top: "5%" }}>
            <Flavours src={require("../assets/fruit/strawberry.png")} name="Fragola" LimitHandler={check} color="#b96e62" />
            <Flavours src={require("../assets/fruit/peach.png")} name="Pesca" LimitHandler={check} color="#ffcc99" />
            <Flavours src={require("../assets/fruit/lemon.png")} name="Limone" LimitHandler={check} color="#fff44f" />
            <Flavours src={require("../assets/fruit/melon.png")} name="Melone" LimitHandler={check} color="#f79862" />
        </View>
    </SafeAreaView>
)
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#fff",
        paddingTop: Platform.OS === "android" ? StatusBar.currentHeight : 0
    },

})  