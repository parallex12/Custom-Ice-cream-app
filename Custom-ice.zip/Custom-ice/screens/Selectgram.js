import React, { useState } from "react";
import { StyleSheet, Text, View,StatusBar, Image} from "react-native";
import Header from "../components/Header";
import { SafeAreaView } from "react-native-safe-area-context";
import { TouchableOpacity } from "react-native-gesture-handler";

export default function Editor({navigation,route}){
    return(
        <SafeAreaView style={styles.container}>
            {/* header component */}
            <Header/>
            {/* header component */}
            <View style={{top:"20%"}}>
                <Text style={{fontWeight:"bold",fontSize:25,textAlign:"center"}}>Confezione: {route.params.pack}</Text>
            </View>
            <View style={{flex:1,flexDirection:"row",alignItems:"center",bottom:"20%"}}>
                <View style={{flex:1,display:route.params.displayType,height:"12%"}}>
                    <TouchableOpacity style={styles.gramBox} onPress={()=>navigation.navigate('Editor',{gram:"500",pack:route.params.pack,limit:3})}>
                    <Image source={require('../assets/gramicons/500g.png')} style={{height:"100%"}} />
                    </TouchableOpacity>
                </View>

                <View style={{flex:1,height:"12%"}}>
                    <TouchableOpacity style={styles.gramBox} onPress={()=>navigation.navigate('Editor',{gram:"750",pack:route.params.pack,limit:4})}>
                    <Image source={require('../assets/gramicons/750g.png')} style={{height:"100%"}} />
                    </TouchableOpacity>
                </View>

                <View style={{flex:1,display:route.params.displayType,height:"12%"}} >
                    <TouchableOpacity style={styles.gramBox} onPress={()=>navigation.navigate('Editor',{gram:"1000",pack:route.params.pack,limit:6})}>
                    <Image source={require('../assets/gramicons/1000g.png')} style={{height:"100%"}} />
                    </TouchableOpacity>
                </View>



            </View>
        </SafeAreaView>
    )
}
const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: "#fff",
     
    },
    gramBox:{
        marginHorizontal:10,
        alignItems:"center",       
        height:"100%",
        
    }
})  