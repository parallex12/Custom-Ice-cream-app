import React, { useState } from "react";
import { StyleSheet, Text, SafeAreaView,View,Platform ,StatusBar,Image,TouchableOpacity} from "react-native";
import Nextbtn from "../components/Nextbtn";
import Header from "../components/Header";
export default function Packing({navigation,route}) {

const [wPacking,setwPacking]=useState(false)
const [wWpacking,setwWpacking]=useState(false)
const [packing,setPacking]=useState()
const changePack1=()=>{
    if(wPacking==true){
        setwPacking(false) 
        setPacking(null)    
    }else{
        setwPacking(true)
        setwWpacking(false)
        setPacking("Waffer")
    }
  
}
const changePack2=()=>{
    if(wWpacking==true){
        setwWpacking(false)
        setPacking(null)      
    }else{
        setwWpacking(true)
        setwPacking(false)
        setPacking("Classica")
    }
  
}

const nextFunc=()=>{
  packing==null?alert("Scegli in confezione"):packing=="Waffer"?navigation.navigate("Selectgram",{pack:packing,displayType:"none"}):navigation.navigate("Selectgram",{pack:packing,displayType:"flex"})
  
}
return (
  <SafeAreaView style={styles.container}>
    <Header/>
    <View style={styles.selectPack}>
    <Text style={{color:'#222',fontWeight:"700",fontSize:20,paddingBottom:30}}>Scegli la confezione</Text>

      {/* Packings components Starts here*/}
      <View style={{flexDirection:"row",flex:1}}>
        {/* Waffer Packing components Starts here*/}
        <TouchableOpacity style={[styles.wafferSelected,{borderColor:wPacking?"#e49233d4":null,borderWidth:wPacking?3:0}]} onPress={changePack1}>
        <Image resizemode="cover" source={require("../assets/packing/Waffer.png")} style={{width:'100%',height:'100%'}}     />
        </TouchableOpacity>
        
        {/* Waffer Packing components ends here*/}       
         
        {/* Waffer White Packing components Starts here*/}       
        <TouchableOpacity style={[styles.wafferSelected,{borderColor:wWpacking?"#e49233d4":null,borderWidth:wWpacking?3:0}]} onPress={changePack2}>
        <Image resizemode="cover" source={require("../assets/packing/Classica.png")} style={{width:'100%',height:'100%'}}     />
        </TouchableOpacity>
      {/* Waffer White Packing components ends here*/}       
      </View>
      <View style={{flexDirection:"row",flex:1}}>
      <Text style={{flex:1,textAlign:"center",marginTop:10}}>Disponibile solo per la confezione da 750gr</Text>
      <Text style={{flex:1,textAlign:"center",marginTop:10}}>Disponibile solo per la confezione da 500gr, 750gr, 1000gr</Text>
      </View>
      {/* Packings components Ends here*/}
      <View style={{flex:1,flexDirection:"row",top:40}}>
        <Nextbtn handler={nextFunc}/>
      </View>
    </View>

  </SafeAreaView>
);

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    paddingTop:Platform.OS === "android" ? StatusBar.currentHeight  :0
  },

  selectPack:{
    width:"100%",
    height:"70%",
    backgroundColor:"#fff",
    paddingTop:'20%',
    alignItems:"center"
    
  },

  wafferSelected:{
    borderWidth:3,  
    borderRadius:20,
    width:'40%',
    height:'100%',
    marginRight:15,
    justifyContent:"center",
    padding:10
},

  
});
