import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import Packing from "../screens/Packing";
import Editor from "../screens/Editor";
import Selectgram from "../screens/Selectgram";
import Checkout from "../screens/Checkout";

const { Navigator, Screen } = createStackNavigator();

const HomeNavigator = () => (
  <Navigator headerMode="none">
    <Screen name="Packing" component={Packing} />
    <Screen name="Editor" component={Editor} />
    <Screen name="Selectgram" component={Selectgram} />
    <Screen name="Checkout" component={Checkout} />
  </Navigator>
);

export const AppNavigator = () => (
  <NavigationContainer>
    <HomeNavigator />
  </NavigationContainer>
);