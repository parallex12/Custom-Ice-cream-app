import React, { useState } from "react";
import Packing from "./screens/Packing";
import { AppNavigator } from "./routes/AppNavigator";
export default function App() {
return (
  // Packing screen 
  <AppNavigator />
  // Packing screen 
);

}


