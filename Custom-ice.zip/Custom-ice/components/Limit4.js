import React from "react";
import { StyleSheet, View} from "react-native";


export default function Limit4({bg,left,bRadius,bWidth,bTop,brRadius,bRotate}){
    return(
            <View style={[styles.rectangle,{backgroundColor: bg,left:left,borderTopLeftRadius:bRadius,width:bWidth,top:bTop,borderBottomRightRadius:brRadius,rotation:bRotate}]} ></View>      
    )
}


const styles = StyleSheet.create({
    rectangle: {
        height: "26%",
        position: 'absolute', 
        zIndex: 99,        
      },    
  });