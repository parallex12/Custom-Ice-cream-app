import React from "react";
import { StyleSheet, Button,TouchableOpacity, View, Text} from "react-native";

export default function Nextbtn({handler}){
    return(
    //  <Button title="next" color="#e49233d4" style={styles.btn} onPress={()=>handler()} />   
     <TouchableOpacity  onPress={()=>handler()}>
         <View  style={styles.btn}>
             <Text style={{color:"#fff",fontWeight:"bold",fontSize:16,textAlign:"center"}}>Avanti</Text>
         </View>
     </TouchableOpacity>
    )
}


const styles = StyleSheet.create({
    btn:{
        paddingHorizontal:50,
        paddingVertical:15,
        backgroundColor:"#e49233d4",
        borderRadius:15,
   }
    
  });