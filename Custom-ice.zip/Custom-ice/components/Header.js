import React from "react";
import { StyleSheet, Image, View} from "react-native";

export default function Header({handler}){
    return( 
        <View style={styles.header}>
            <Image resizeMode = 'contain' source={require('../assets/header.png')} style={styles.thumbnail} />
        </View>
    )
}


const styles = StyleSheet.create({
    thumbnail: {
        flex: 1,
        width:'20%',
        height:'20%',
        resizeMode: 'cover'
      },  
      header:{
        backgroundColor:"#e49233d4",
        paddingBottom:0,
        alignItems:"center",
        justifyContent:"center",
        height:60,
      },
    
  });