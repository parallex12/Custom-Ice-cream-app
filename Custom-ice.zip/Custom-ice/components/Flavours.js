import React from "react";
import { StyleSheet,TouchableOpacity, View, Image, Text} from "react-native";
import { Colors } from "react-native/Libraries/NewAppScreen";

export default function Flavours({src,name,LimitHandler,color,bWidth}){

    return(
        <View style={{flex:1,height:"100%",width:"30%"}} >
            <TouchableOpacity style={[styles.gramBox,{borderWidth:bWidth}]} onPress={()=>LimitHandler(color,name)}>
            <Image source={src}/>
            <Text style={{fontSize:10,fontWeight:"bold",textAlign:"center"}}>{name}</Text>
            </TouchableOpacity>
        </View>
    )
}


const styles = StyleSheet.create({
    gramBox:{
        marginHorizontal:10,
        alignItems:"center",
        paddingVertical:5    
    }
    
  });